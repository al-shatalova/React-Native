import React, {useState} from 'react';
import {
  FlatList,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  Image,
  View,
  TouchableOpacity,
} from 'react-native';

const DATA = [
  {
    id: '01',
    title: 'Иванов Петр',
  },
  {
    id: '02',
    title: 'Сидорова Василиса',
  },
  {
    id: '4',
    title: 'Петров Василий',
    uri: 'https://www.happymigration.com/wp-content/uploads/2015/02/student01.jpg',
  },
];

const Item = ({item, onPress, backgroundColor, textColor}) => (
  <TouchableOpacity onPress={onPress} style={[styles.item, {backgroundColor}]}>
   <View style={styles.container1}>
  <Image
  source={{uri: 'https://www.happymigration.com/wp-content/uploads/2015/02/student01.jpg'}}
  style={{width: 40, height: 40}}
/>
    <Text style={[styles.title, {color: textColor}]}>{item.title}</Text>
    </View>
  </TouchableOpacity>
);

const App = () => {
  const [selectedId, setSelectedId] = useState();

  const renderItem = ({item}) => {
    const backgroundColor = item.id === selectedId ? '#E9E9E9' : '#EFEFEF';
    const color = item.id === selectedId ? 'gray' : 'black';

    return (
      <Item
        item={item}
        onPress={() => setSelectedId(item.id)}
        backgroundColor={backgroundColor}
        textColor={color}
      />
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        extraData={selectedId}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: StatusBar.currentHeight || 0,
  },
  item: {
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 20,
    margin: 6,
  },
  container1: {
    flex: 1,
    flexDirection: 'row',
  },
});

export default App;