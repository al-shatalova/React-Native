import React, {useRef} from 'react';
import {Animated, PanResponder, StyleSheet, View, ImageBackground, Image} from 'react-native';

const image = {uri: 'https://sun9-73.userapi.com/impg/UZHkT8EQqNFkktUkkZOUJWANi6ncP9apkdgZnw/V5DEibsQ3cc.jpg?size=414x604&quality=96&sign=1d2a0e4b0190a00d850497692254560f&type=album'};

const DraggableView = () => {
  const pan = useRef(new Animated.ValueXY()).current;

  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: Animated.event([
      null,
      {
        dx: pan.x, // x,y are Animated.Value
        dy: pan.y,
      },
    ]),
    onPanResponderRelease: () => {
      Animated.spring(
        pan, // Auto-multiplexed
        {toValue: {x: -5, y: -15}, useNativeDriver: true}, // Back to zero
      ).start();
    },
  });

  return (
     <ImageBackground source={image} resizeMode="cover" style={styles.image}>
    <View style={styles.container}>
      <Animated.View
        {...panResponder.panHandlers}
        style={[pan.getLayout()]}><Image
          source={{
            uri: 'https://reactnative.dev/docs/assets/p_cat2.png',
          }}
          style={{width: 100, height: 100}}
        /> </Animated.View>
    </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  box: {
    backgroundColor: '#61dafb',
    width: 80,
    height: 80,
    borderRadius: 4,
  },
    image: {
    flex: 1,
    justifyContent: 'center',
    }
});

export default DraggableView;